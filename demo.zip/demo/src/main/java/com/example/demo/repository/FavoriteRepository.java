package com.example.demo.repository;

import com.example.demo.model.Favorite;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FavoriteRepository extends JpaRepository<Favorite, Long> {

    // 根据用户ID查找收藏
    List<Favorite> findByUserId(Long userId);

    // 根据剧集ID查找收藏
    List<Favorite> findByDramaId(Long dramaId);
}
