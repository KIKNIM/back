//package com.example.demo.controller;
//
//import com.example.demo.model.Message;
//import com.example.demo.service.MessageService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;
//
//@RestController
//@RequestMapping("/api/messages")
//public class MessageRestController {
//
//    @Autowired
//    private MessageService messageService;
//
//    // 获取历史消息
//    @PostMapping("/history/{user1}/{user2}")
//    public List<Message> getChatHistory(@PathVariable String user1, @PathVariable String user2) {
//        return messageService.getMessagesBetweenUsers(user1, user2);
//    }
//
//    // 标记消息为已读
//    @PutMapping("/{id}/read")
//    public void markAsRead(@PathVariable Long id) {
//        messageService.markMessageAsRead(id);
//    }
//}
