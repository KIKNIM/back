package com.example.demo.controller;

import com.example.demo.model.User;
import com.example.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/users")
public class UserController {
    @PostMapping("/login")
    public ResponseEntity<?> loginUser(@RequestBody Map<String, String> payload) {
        String phone = payload.get("phone_number");
        String password = payload.get("password");
        System.out.println("[登录] 收到请求：phone=" + phone + ", password=" + password);

        Optional<User> user = userService.loginUser(phone, password);
        if (user.isPresent()) {
//            return ResponseEntity.ok("你成功了");
            return ResponseEntity.ok(user.get());  // 返回找到的用户对象
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("手机号或密码错误");
        }
    }

    @Autowired
    private UserService userService;

    // 注册新用户
    @PostMapping("/register")
    public User registerUser(@RequestBody User user) {
        return userService.registerUser(user);
    }

    // 根据用户名获取用户
    @GetMapping("/username/{username}")
    public Optional<User> getUserByUsername(@PathVariable String username) {
        return userService.findUserByUsername(username);
    }

//    // 根据邮箱获取用户
//    @GetMapping("/email/{email}")
//    public Optional<User> getUserByEmail(@PathVariable String email) {
//        return userService.findUserByEmail(email);
//    }

    // 根据手机号获取用户
    @GetMapping("/phone/{phoneNumber}")
    public Optional<User> getUserByPhoneNumber(@PathVariable String phoneNumber) {
        return userService.findUserByPhoneNumber(phoneNumber);
    }

    // 更新用户信息
    @PutMapping("/{userId}")
    public User updateUser(@PathVariable Long userId, @RequestBody User user) {
        return userService.updateUser(userId, user);
    }

    // 删除用户
    @DeleteMapping("/{userId}")
    public void deleteUser(@PathVariable Long userId) {
        userService.deleteUser(userId);
    }
}
