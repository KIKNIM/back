package com.example.demo.service;

import com.example.demo.model.Friendship;

import java.util.List;

public interface FriendshipService {
    void addFriend(String userId, String friendId);
    List<String> getFriends(String userId);
    boolean isFriend(String userId, String friendId);
}
