package com.example.demo.service;

import com.example.demo.model.Share;

import java.util.List;

public interface ShareService {

    Share createShare(Share share);

    List<Share> getSharesByUser(Long userId);

    List<Share> getSharesByDrama(Long dramaId);
}
