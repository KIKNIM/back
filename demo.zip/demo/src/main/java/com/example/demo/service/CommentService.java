package com.example.demo.service;

import com.example.demo.model.Comment;
import java.util.List;

public interface CommentService {
    List<Comment> getCommentsByDrama(Long dramaId);
    Comment addComment(Comment comment);
    void deleteComment(Long id);
}
