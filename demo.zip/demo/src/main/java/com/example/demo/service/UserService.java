package com.example.demo.service;

import com.example.demo.model.User;

import java.util.Optional;

public interface UserService {

    User registerUser(User user);

    Optional<User> findUserByUsername(String username);

//    Optional<User> findUserByEmail(String email);

    Optional<User> findUserByPhoneNumber(String phoneNumber);

    User updateUser(Long userId, User user);

    void deleteUser(Long userId);
    Optional<User> loginUser(String phoneNumber, String password);

}
