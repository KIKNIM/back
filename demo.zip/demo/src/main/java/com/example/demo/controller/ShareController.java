package com.example.demo.controller;

import com.example.demo.model.Share;
import com.example.demo.service.ShareService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/shares")
public class ShareController {

    @Autowired
    private ShareService shareService;

    // 创建新的分享记录
    @PostMapping
    public Share createShare(@RequestBody Share share) {
        return shareService.createShare(share);
    }

    // 获取指定用户的所有分享记录
    @GetMapping("/user/{userId}")
    public List<Share> getSharesByUser(@PathVariable Long userId) {
        return shareService.getSharesByUser(userId);
    }

    // 获取指定短剧的所有分享记录
    @GetMapping("/drama/{dramaId}")
    public List<Share> getSharesByDrama(@PathVariable Long dramaId) {
        return shareService.getSharesByDrama(dramaId);
    }
}
