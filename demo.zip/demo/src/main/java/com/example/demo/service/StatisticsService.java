package com.example.demo.service;

import com.example.demo.model.Statistics;

import java.util.List;

public interface StatisticsService {

    Statistics createOrUpdateStatistics(Statistics statistics);

    List<Statistics> getStatisticsByUser(Long userId);

    List<Statistics> getStatisticsByDrama(Long dramaId);

    Statistics getStatisticsByUserAndDrama(Long userId, Long dramaId);
}
