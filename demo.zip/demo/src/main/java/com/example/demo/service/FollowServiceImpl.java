package com.example.demo.service;

import com.example.demo.model.Follow;
import com.example.demo.model.User;
import com.example.demo.repository.FollowRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FollowServiceImpl implements FollowService {

    @Autowired
    private FollowRepository followRepository;

    // 获取某个用户的所有关注者（即粉丝）
    @Override
    public List<Follow> getFollowersByUser(Long userId) {
        return followRepository.findByFollowing_Id(userId); // 修正方法名
    }

    // 获取某个用户关注的所有人
    @Override
    public List<Follow> getFollowingByUser(Long userId) {
        return followRepository.findByFollower_Id(userId); // 修正方法名
    }

    // 关注某个用户
    @Override
    public Follow followUser(Long followerId, Long followedId) {
        Follow follow = new Follow();

        // 构造 follower 对象
        User follower = new User();
        follower.setId(followerId);
        follow.setFollower(follower);

        // 构造 following 对象
        User following = new User();
        following.setId(followedId);
        follow.setFollowing(following);

        return followRepository.save(follow);
    }

    // 取消关注
    @Override
    public void unfollowUser(Long followerId, Long followedId) {
        followRepository.deleteByFollower_IdAndFollowing_Id(followerId, followedId);
    }
}
