package com.example.demo.repository;

import com.example.demo.model.Message;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface MessageRepository extends JpaRepository<Message, Long> {

    List<Message> findBySenderIdOrReceiverId(Long senderId, Long receiverId);
        // 自定义插入方法
    @Modifying
    @Transactional
    @Query("INSERT INTO Message (id, content, timestamp, status, senderId, receiverId, sender_username,receiver_username) " +
           "VALUES (:id, :content, :timestamp, :status, :senderId, :receiverId, :senderUsername,:receiverUsername)")
    int saveCustomMessage_my(
        @Param("id") long id,
        @Param("content") String content,
        @Param("timestamp") long timestamp,
        @Param("status") String status,
        @Param("senderId") long senderId,
        @Param("receiverId") long receiverId,
        @Param("senderUsername") String senderUsername,
        @Param("receiverUsername") String receiverUsername
    );

}
