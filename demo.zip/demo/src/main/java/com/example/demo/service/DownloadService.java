package com.example.demo.service;

public interface DownloadService {
    // 获取所有可下载的短剧列表
    String getAllDownloads();

    // 下载指定短剧
    String downloadDrama(Long dramaId);
}
