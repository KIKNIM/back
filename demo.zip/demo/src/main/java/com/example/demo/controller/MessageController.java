package com.example.demo.controller;

import com.example.demo.model.Message;
import com.example.demo.service.MessageService;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/messages")
public class MessageController {

    @Autowired
    private MessageService messageService;

    // WebSocket：发送消息
    @MessageMapping("/sendMessage")
    @SendTo("/topic/messages")
    public int sendMessage(Message message) {
        return messageService.saveMessage(message);
    }
//
//    // REST：获取两个用户之间的消息（支持 Get 和 Post 两种形式）
//    @GetMapping("/history/{user1}/{user2}")
//    @PostMapping("/history/{user1}/{user2}")
//    public List<Message> getMessagesBetweenUsers(@PathVariable String user1, @PathVariable String user2) {
//        return messageService.getMessagesBetweenUsers(user1, user2);
//    }

    // REST：获取与某个用户有关的所有消息
    @GetMapping("/user/{userId}")
    @PostMapping("/user/{userId}")
    public List<Message> getMessagesByUserId(@PathVariable Long userId) {
        return messageService.getMessagesByUserId(userId);
    }

    // REST：标记消息为已读
    @PutMapping("/{id}/read")
    public void markAsRead(@PathVariable Long id) {
        messageService.markMessageAsRead(id);
    }

    // 新增接口：保存消息到数据库
    @PostMapping("/save")
    public int saveMessage(@RequestBody Message message) {
        Gson gson = new Gson();
        System.out.println("dadadadadad：" + gson.toJson(message));

        // 保存消息到数据库
        return messageService.saveMessage(message);  // 将消息保存到数据库或其他存储介质
    }

}
