package com.example.demo.repository;

import com.example.demo.model.Statistics;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StatisticsRepository extends JpaRepository<Statistics, Long> {

    List<Statistics> findByUserId(Long userId);

    List<Statistics> findByDramaId(Long dramaId);

    Statistics findByUserIdAndDramaId(Long userId, Long dramaId);
}
