package com.example.demo.controller;

import com.example.demo.service.FriendshipService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/friends")
public class FriendshipController {

    @Autowired
    private FriendshipService friendshipService;

    @PostMapping("/add")
    public String addFriend(@RequestParam String userId, @RequestParam String friendId) {
        friendshipService.addFriend(userId, friendId);
        return "好友添加成功";
    }

    @GetMapping("/{userId}")
    public List<String> getFriends(@PathVariable String userId) {
        return friendshipService.getFriends(userId);
    }
}
