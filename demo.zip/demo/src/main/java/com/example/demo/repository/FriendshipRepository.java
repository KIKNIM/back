package com.example.demo.repository;

import com.example.demo.model.Friendship;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FriendshipRepository extends JpaRepository<Friendship, Long> {
    List<Friendship> findByUserIdAndStatus(String userId, Friendship.FriendshipStatus status);

    boolean existsByUserIdAndFriendId(String userId, String friendId);
}
