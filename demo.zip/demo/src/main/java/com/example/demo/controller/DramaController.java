package com.example.demo.controller;

import com.example.demo.model.Drama;
import com.example.demo.service.DramaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/dramas")
public class DramaController {

    @Autowired
    private DramaService dramaService;

    // 获取剧集列表
    @GetMapping
    public List<Drama> getAllDramas() {
        return dramaService.getAllDramas();
    }

    // 按类型分类
    @GetMapping("/category/{category}")
    public List<Drama> getDramasByCategory(@PathVariable String category) {
        return dramaService.getDramasByCategory(category);
    }

    // 搜索剧集
    @GetMapping("/search")
    public List<Drama> searchDramas(@RequestParam String title) {
        return dramaService.searchDramas(title);
    }

    // 推荐剧集
    @GetMapping("/recommended")
    public List<Drama> getRecommendedDramas() {
        return dramaService.getRecommendedDramas();
    }

    // 获取剧集详情
    @GetMapping("/{dramaId}")
    public Optional<Drama> getDramaById(@PathVariable Long dramaId) {
        return dramaService.getDramaById(dramaId);
    }
}
