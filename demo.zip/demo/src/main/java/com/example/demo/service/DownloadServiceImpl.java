package com.example.demo.service;

import com.example.demo.service.DownloadService;
import org.springframework.stereotype.Service;

@Service
public class DownloadServiceImpl implements DownloadService {

    @Override
    public String getAllDownloads() {
        // 这里可以添加逻辑，返回所有可下载的短剧列表
        // 示例返回
        return "List of downloadable dramas";
    }

    @Override
    public String downloadDrama(Long dramaId) {
        // 这里可以添加实际的下载逻辑
        // 示例返回
        return "Drama " + dramaId + " downloaded successfully";
    }
}
