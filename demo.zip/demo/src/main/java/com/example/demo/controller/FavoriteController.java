package com.example.demo.controller;

import com.example.demo.model.Favorite;
import com.example.demo.service.FavoriteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/favorites")
public class FavoriteController {

    @Autowired
    private FavoriteService favoriteService;

    // 获取某个用户的所有收藏
    @GetMapping("/user/{userId}")
    public List<Favorite> getFavoritesByUser(@PathVariable Long userId) {
        return favoriteService.getFavoritesByUser(userId);
    }

    // 添加收藏
    @PostMapping
    public Favorite addFavorite(@RequestBody Favorite favorite) {
        return favoriteService.addFavorite(favorite);
    }

    // 删除收藏
    @DeleteMapping("/{id}")
    public void deleteFavorite(@PathVariable Long id) {
        favoriteService.deleteFavorite(id);
    }

    // 获取某个短剧的所有收藏
    @GetMapping("/drama/{dramaId}")
    public List<Favorite> getFavoritesByDrama(@PathVariable Long dramaId) {
        return favoriteService.getFavoritesByDrama(dramaId);
    }
}
