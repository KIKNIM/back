package com.example.demo.repository;

import com.example.demo.model.Drama;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DramaRepository extends JpaRepository<Drama, Long> {

    List<Drama> findByCategory(String category);

    List<Drama> findByTitleContainingIgnoreCase(String title);

    List<Drama> findTop10ByOrderByRatingDesc();
}
