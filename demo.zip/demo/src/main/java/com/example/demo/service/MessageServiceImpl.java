package com.example.demo.service;

import com.example.demo.model.Message;
//import com.example.demo.model.Message.MessageStatus;
import com.example.demo.repository.MessageRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MessageServiceImpl implements MessageService {

    @Autowired
    private MessageRepository messageRepository;

    @Autowired
    private FriendshipService friendshipService;

    @Override
    @Transactional
    public int saveMessage(Message message) {
        message.setStatus("SENT");
        return messageRepository.saveCustomMessage_my(
                message.getId(),
                message.getContent(),
                message.getTimestamp(),
                message.getStatus(),
                message.getSenderId(),
                message.getReceiverId(),
                message.getSender_username(),
                message.getReceiver_username()
        );
    }

//    @Override
//    public List<Message> getMessagesBetweenUsers(String user1, String user2) {
////        if (friendshipService.isFriend(user1, user2)) {
//            // 构造用于测试的消息列表
////            List<Message> messages = new ArrayList<>();
////            messages.add(new Message(user1, user2, "测试消息一", LocalDateTime.now().minusMinutes(2)));
////            messages.add(new Message(user2, user1, "测试消息二", LocalDateTime.now()));
////            return messages;
//
//            // 如果你想恢复正式功能可以取消注释下面这行：
//             return messageRepository.findBySenderAndReceiverOrReceiverAndSender(user1, user2, user1, user2);
////        }
//
//    }

        @Override
    public List<Message> getMessagesByUserId(Long userId) {

             return messageRepository.findBySenderIdOrReceiverId(userId,userId);
    }

    @Override
    public void markMessageAsRead(Long messageId) {
        Optional<Message> optional = messageRepository.findById(messageId);
        if (optional.isPresent()) {
            Message message = optional.get();
            message.setStatus("READ");
            messageRepository.save(message);
        }
    }
}
