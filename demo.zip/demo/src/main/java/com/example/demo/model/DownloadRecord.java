package com.example.demo.model;

import jakarta.persistence.*;

import java.time.LocalDateTime;
import java.util.Date;

@Entity
@Table(name = "download_record")
public class DownloadRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;  // 下载记录的唯一标识

    private Long userId;  // 用户ID，表示谁进行的下载

    private Long dramaId;  // 剧集ID，表示下载的是哪一集

    private LocalDateTime downloadTime;  // 下载时间

    private String filePath;  // 存储文件的路径或下载链接

    public DownloadRecord() {
    }

    public DownloadRecord(Long userId, Long dramaId, LocalDateTime downloadTime, String filePath) {
        this.userId = userId;
        this.dramaId = dramaId;
        this.downloadTime = downloadTime;
        this.filePath = filePath;
    }

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getDramaId() {
        return dramaId;
    }

    public void setDramaId(Long dramaId) {
        this.dramaId = dramaId;
    }

    public LocalDateTime getDownloadTime() {
        return downloadTime;
    }

    public void setDownloadTime(LocalDateTime downloadTime) {
        this.downloadTime = downloadTime;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    @Override
    public String toString() {
        return "DownloadRecord{" +
                "id=" + id +
                ", userId=" + userId +
                ", dramaId=" + dramaId +
                ", downloadTime=" + downloadTime +
                ", filePath='" + filePath + '\'' +
                '}';
    }
}
