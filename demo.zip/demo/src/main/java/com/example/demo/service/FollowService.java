package com.example.demo.service;

import com.example.demo.model.Follow;
import java.util.List;

public interface FollowService {

    // 获取某个用户的所有关注
    List<Follow> getFollowersByUser(Long userId);

    // 获取某个用户的所有被关注
    List<Follow> getFollowingByUser(Long userId);

    // 关注一个用户
    Follow followUser(Long followerId, Long followedId);

    // 取消关注
    void unfollowUser(Long followerId, Long followedId);
}
