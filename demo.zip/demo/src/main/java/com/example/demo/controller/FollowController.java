package com.example.demo.controller;

import com.example.demo.model.Follow;
import com.example.demo.service.FollowService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/follow")
public class FollowController {

    @Autowired
    private FollowService followService;

    // 获取某个用户的所有关注者
    @GetMapping("/followers/{userId}")
    public List<Follow> getFollowers(@PathVariable Long userId) {
        return followService.getFollowersByUser(userId);
    }

    // 获取某个用户关注的所有人
    @GetMapping("/following/{userId}")
    public List<Follow> getFollowing(@PathVariable Long userId) {
        return followService.getFollowingByUser(userId);
    }

    // 关注某个用户
    @PostMapping("/follow")
    public Follow followUser(@RequestParam Long followerId, @RequestParam Long followedId) {
        return followService.followUser(followerId, followedId);
    }

    // 取消关注
    @DeleteMapping("/unfollow")
    public void unfollowUser(@RequestParam Long followerId, @RequestParam Long followedId) {
        followService.unfollowUser(followerId, followedId);
    }
}
