package com.example.demo.service;

import com.example.demo.model.Statistics;
import com.example.demo.repository.StatisticsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StatisticsServiceImpl implements StatisticsService {

    @Autowired
    private StatisticsRepository statisticsRepository;

    @Override
    public Statistics createOrUpdateStatistics(Statistics statistics) {
        return statisticsRepository.save(statistics);
    }

    @Override
    public List<Statistics> getStatisticsByUser(Long userId) {
        return statisticsRepository.findByUserId(userId);
    }

    @Override
    public List<Statistics> getStatisticsByDrama(Long dramaId) {
        return statisticsRepository.findByDramaId(dramaId);
    }

    @Override
    public Statistics getStatisticsByUserAndDrama(Long userId, Long dramaId) {
        return statisticsRepository.findByUserIdAndDramaId(userId, dramaId);
    }
}
