package com.example.demo.service;

import com.example.demo.model.Friendship;
import com.example.demo.repository.FriendshipRepository;
import com.example.demo.service.FriendshipService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class FriendshipServiceImpl implements FriendshipService {

    @Autowired
    private FriendshipRepository friendshipRepository;

    @Override
    public void addFriend(String userId, String friendId) {
        if (!friendshipRepository.existsByUserIdAndFriendId(userId, friendId)) {
            friendshipRepository.save(new Friendship(userId, friendId, Friendship.FriendshipStatus.ACCEPTED));
        }
        if (!friendshipRepository.existsByUserIdAndFriendId(friendId, userId)) {
            friendshipRepository.save(new Friendship(friendId, userId, Friendship.FriendshipStatus.ACCEPTED));
        }
    }

    @Override
    public List<String> getFriends(String userId) {
        return friendshipRepository.findByUserIdAndStatus(userId, Friendship.FriendshipStatus.ACCEPTED)
                .stream()
                .map(Friendship::getFriendId)
                .collect(Collectors.toList());
    }

    @Override
    public boolean isFriend(String userId, String friendId) {
        return friendshipRepository.existsByUserIdAndFriendId(userId, friendId);
    }
}
