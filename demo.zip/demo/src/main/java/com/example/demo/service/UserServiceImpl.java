package com.example.demo.service;

import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {
    @Override
    public Optional<User> loginUser(String phoneNumber, String password) {
    Optional<User> user = userRepository.findByPhoneNumber(phoneNumber);
    if (user.isPresent() && user.get().getPassword().equals(password)) {
        return user; // 登录成功
    }
    return Optional.empty(); // 登录失败
}

    @Autowired
    private UserRepository userRepository;

    @Override
    public User registerUser(User user) {
        // Here you can add password encoding before saving, if necessary
        return userRepository.save(user);
    }

    @Override
    public Optional<User> findUserByUsername(String username) {
        return userRepository.findByUsername(username);
    }

//    @Override
//    public Optional<User> findUserByEmail(String email) {
//        return userRepository.findByEmail(email);
//    }

    @Override
    public Optional<User> findUserByPhoneNumber(String phoneNumber) {
        return userRepository.findByPhoneNumber(phoneNumber);
    }

    @Override
    public User updateUser(Long userId, User user) {
        user.setId(userId); // Set the ID to ensure we update the correct record
        return userRepository.save(user);
    }

    @Override
    public void deleteUser(Long userId) {
        userRepository.deleteById(userId);
    }
}
