package com.example.demo.repository;

import com.example.demo.model.Follow;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FollowRepository extends JpaRepository<Follow, Long> {

    // 查找关注某用户的所有人（即这个用户的粉丝）
    List<Follow> findByFollowing_Id(Long userId);

    // 查找某个用户关注的所有人（即他关注了谁）
    List<Follow> findByFollower_Id(Long userId);

    // 根据用户取消关注
    void deleteByFollower_IdAndFollowing_Id(Long followerId, Long followingId);
}
