package com.example.demo.service;

import com.example.demo.model.Share;
import com.example.demo.repository.ShareRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ShareServiceImpl implements ShareService {

    @Autowired
    private ShareRepository shareRepository;

    @Override
    public Share createShare(Share share) {
        return shareRepository.save(share);
    }

    @Override
    public List<Share> getSharesByUser(Long userId) {
        return shareRepository.findByUserId(userId);
    }

    @Override
    public List<Share> getSharesByDrama(Long dramaId) {
        return shareRepository.findByDramaId(dramaId);
    }
}
