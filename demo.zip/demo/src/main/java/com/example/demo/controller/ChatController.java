package edu.cczu.mytest.controller;

import com.example.demo.model.Message;
//import com.example.demo.model.Message.MessageStatus;
import com.example.demo.repository.MessageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;

import java.time.LocalDateTime;

@Controller
public class ChatController {

    @Autowired
    private MessageRepository messageRepository;

    @MessageMapping("/chat")         // 客户端发到 /app/chat
    @SendTo("/topic/public")         // 广播到所有订阅 /topic/public 的客户端
    public Message handleMessage(Message incoming) {
        // 设置时间戳和状态
//        incoming.setTimestamp(LocalDateTime.now());
        incoming.setStatus("SENT"); // 默认设置为 SENT

        // 保存消息到数据库
        Message saved = messageRepository.save(incoming);

        System.out.println("保存消息：" + saved.getContent());

        // 返回给订阅者
        return saved;
    }
}
