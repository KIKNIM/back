package com.example.demo.controller;

import org.json.JSONObject;
import org.springframework.web.socket.*;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.net.URI;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class WebSocketHandler extends TextWebSocketHandler {

    // 存储在线用户 userId -> WebSocketSession
    private static final Map<Integer, WebSocketSession> onlineUsers = new ConcurrentHashMap<>();

    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
        System.out.println("新客户端连接：" + session.getId());

        // 从 URI 获取 userId，例如 ws://localhost:8080/ws?userId=275
        URI uri = session.getUri();
        if (uri != null && uri.getQuery() != null) {
            String[] params = uri.getQuery().split("&");
            for (String param : params) {
                if (param.startsWith("userId=")) {
                    // 使用 try-catch 捕获可能的 NumberFormatException
                    try {
                        // 获取 userId 参数值并转换为整数
                        String userIdStr = param.split("=")[1];
                        int userId = Integer.parseInt(userIdStr);
                        onlineUsers.put(userId, session);
                        session.getAttributes().put("userId", userId);
                        System.out.println("用户 " + userId + " 上线");

                        // 通知其他在线用户该用户上线
//                        broadcastSystemMessage("用户 " + userId + " 已上线", userId);
                    } catch (NumberFormatException e) {
                        System.err.println("无效的 userId 参数: " + param.split("=")[1]);
                    }
                    break;
                }
            }
        }
    }


    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
        System.out.println("服务器接收到消息：" + message.getPayload());

        // 解析消息内容
        JSONObject jsonMessage = new JSONObject(message.getPayload());
        Integer senderId = jsonMessage.getInt("senderId");
        Integer receiverId = jsonMessage.getInt("receiverId");
        String content = jsonMessage.getString("content");

        // 向发送者发送回执
//        session.sendMessage(new TextMessage("服务器收到来自 " + senderId + " 的消息：" + content));

        // 转发给接收者
        WebSocketSession receiverSession = onlineUsers.get(receiverId);
        if (receiverSession != null && receiverSession.isOpen()) {
            try {
                receiverSession.sendMessage(new TextMessage(content));
                System.out.println("消息转发成功：from " + senderId + " to " + receiverId + " 内容：" + content);
            } catch (Exception e) {
                System.err.println("转发消息失败：" + e.getMessage());
            }
        } else {
            System.out.println("用户 " + receiverId + " 不在线，无法转发消息");
        }
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) throws Exception {
        System.out.println("客户端断开连接：" + session.getId());

        Object userIdObj = session.getAttributes().get("userId");
        if (userIdObj instanceof Integer) {
            int userId = (Integer) userIdObj;
            onlineUsers.remove(userId);
            System.out.println("用户 " + userId + " 已下线");

            // 通知其他用户该用户下线
//            broadcastSystemMessage("用户 " + userId + " 已下线", userId);
        }
    }

    /**
     * 向所有在线用户广播系统消息，排除某个用户（例如刚上线者）
     */
    private void broadcastSystemMessage(String content, int excludeUserId) {
        JSONObject message = new JSONObject();
        message.put("senderId", 0); // 0 表示系统消息
        message.put("receiverId", -1); // -1 表示广播
        message.put("content", content);

        TextMessage systemMessage = new TextMessage(message.toString());

        for (Map.Entry<Integer, WebSocketSession> entry : onlineUsers.entrySet()) {
            int userId = entry.getKey();
            WebSocketSession session = entry.getValue();
            if (userId != excludeUserId && session.isOpen()) {
                try {
                    session.sendMessage(systemMessage);
                } catch (Exception e) {
                    System.err.println("向用户 " + userId + " 发送系统消息失败：" + e.getMessage());
                }
            }
        }
    }

    /**
     * 外部可调用方法：向指定用户发送消息
     */
    public static boolean sendMessageToUser(int userId, TextMessage message) {
        WebSocketSession session = onlineUsers.get(userId);
        if (session != null && session.isOpen()) {
            try {
                session.sendMessage(message);
                return true;
            } catch (Exception e) {
                System.err.println("发送消息失败：" + e.getMessage());
            }
        }
        return false;
    }
}
