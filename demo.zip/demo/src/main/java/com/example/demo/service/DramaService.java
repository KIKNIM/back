package com.example.demo.service;

import com.example.demo.model.Drama;

import java.util.List;
import java.util.Optional;

public interface DramaService {

    List<Drama> getAllDramas();

    List<Drama> getDramasByCategory(String category);

    List<Drama> searchDramas(String title);

    List<Drama> getRecommendedDramas();

    Optional<Drama> getDramaById(Long dramaId);
}
