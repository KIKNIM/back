package com.example.demo.model;

import jakarta.persistence.*;

@Entity
@Table(name = "friendships")
public class Friendship {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String userId;     // 当前用户ID
    private String friendId;   // 好友用户ID

    @Enumerated(EnumType.STRING)
    private FriendshipStatus status;

    public enum FriendshipStatus {
        PENDING, ACCEPTED, BLOCKED
    }

    public Friendship() {}

    public Friendship(String userId, String friendId, FriendshipStatus status) {
        this.userId = userId;
        this.friendId = friendId;
        this.status = status;
    }

    public Long getId() { return id; }

    public String getUserId() { return userId; }

    public void setUserId(String userId) { this.userId = userId; }

    public String getFriendId() { return friendId; }

    public void setFriendId(String friendId) { this.friendId = friendId; }

    public FriendshipStatus getStatus() { return status; }

    public void setStatus(FriendshipStatus status) { this.status = status; }
}
