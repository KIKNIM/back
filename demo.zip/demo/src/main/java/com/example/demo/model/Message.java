package com.example.demo.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Message {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String content;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Long timestamp;

    private String sender_username;

    public String getReceiver_username() {
        return receiver_username;
    }

    public void setReceiver_username(String receiver_username) {
        this.receiver_username = receiver_username;
    }

    private String receiver_username;

    public String getSender_username() {
        return sender_username;
    }

    public void setSender_username(String sender_username) {
        this.sender_username = sender_username;
    }


//    @Enumerated(EnumType.STRING)
    private String status;

    // 保持 senderId 和 receiverId 为 String 类型
    @Column(name = "sender_id")
    private Long senderId;  // String 类型，用于存储 User 的 id

    @Column(name = "receiver_id")
    private Long receiverId;  // String 类型，用于存储 User 的 id

    // 默认构造函数（JPA必须）
    public Message() {}

    // 全参数构造函数
    public Message(Long id, Long senderId, Long receiverId, String content, Long  timestamp, String status,String sender_username,String receiver_username) {
        this.id = id;
        this.senderId = senderId;
        this.receiverId = receiverId;
        this.content = content;
        this.timestamp = timestamp;
        this.status = status;
        this.sender_username = sender_username;
        this.receiver_username = receiver_username;
    }

    // Getter 和 Setter
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    public Long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Long getSenderId() {
        return senderId;
    }

    public void setSenderId(Long senderId) {
        this.senderId = senderId;
    }

    public Long getReceiverId() {
        return receiverId;
    }

    public void setReceiverId(Long   receiverId) {
        this.receiverId = receiverId;
    }

//    public enum MessageStatus {
//        SENT,       // 已发送
//        DELIVERED,  // 已送达
//        READ        // 已读
//    }
}
