package com.example.demo.repository;

import com.example.demo.model.DownloadRecord;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface DownloadRecordRepository extends JpaRepository<DownloadRecord, Long> {

    // 根据用户ID查找下载记录
    List<DownloadRecord> findByUserId(Long userId);

    // 根据剧集ID查找下载记录
    List<DownloadRecord> findByDramaId(Long dramaId);

    // 根据下载时间查找下载记录（如果有需要可以加上）
    List<DownloadRecord> findByDownloadTimeAfter(LocalDateTime time);
}
