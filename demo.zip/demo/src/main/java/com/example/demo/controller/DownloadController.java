package com.example.demo.controller;

import com.example.demo.service.DownloadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("api/downloads")
public class DownloadController {

    @Autowired
    private DownloadService downloadService;

    // 获取所有可下载的短剧列表
    @GetMapping("/list")
    public String getAllDownloads() {
        return downloadService.getAllDownloads();
    }

    // 下载指定的短剧
    @GetMapping("/download/{dramaId}")
    public String downloadDrama(@PathVariable Long dramaId) {
        return downloadService.downloadDrama(dramaId);
    }
}
