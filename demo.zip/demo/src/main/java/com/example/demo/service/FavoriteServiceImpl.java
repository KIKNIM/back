package com.example.demo.service;

import com.example.demo.model.Favorite;
import com.example.demo.repository.FavoriteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FavoriteServiceImpl implements FavoriteService {

    @Autowired
    private FavoriteRepository favoriteRepository;

    // 获取某个用户的所有收藏
    @Override
    public List<Favorite> getFavoritesByUser(Long userId) {
        return favoriteRepository.findByUserId(userId);
    }

    // 添加收藏
    @Override
    public Favorite addFavorite(Favorite favorite) {
        return favoriteRepository.save(favorite);
    }

    // 删除收藏
    @Override
    public void deleteFavorite(Long id) {
        favoriteRepository.deleteById(id);
    }

    // 获取某个短剧的所有收藏
    @Override
    public List<Favorite> getFavoritesByDrama(Long dramaId) {
        return favoriteRepository.findByDramaId(dramaId);
    }
}
