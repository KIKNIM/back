package com.example.demo.controller;

import com.example.demo.model.Comment;
import com.example.demo.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/comments")
public class CommentController {
    @GetMapping
    public String baseInfo() {
        return "这里是评论相关接口";
    }
    @Autowired
    private CommentService commentService;

    @GetMapping("/drama/{dramaId}")
    public List<Comment> getCommentsByDrama(@PathVariable Long dramaId) {
        return commentService.getCommentsByDrama(dramaId);
    }

    @PostMapping
    public Comment addComment(@RequestBody Comment comment) {
        return commentService.addComment(comment);
    }

    @DeleteMapping("/{id}")
    public void deleteComment(@PathVariable Long id) {
        commentService.deleteComment(id);
    }
}
