package com.example.demo.service;

import com.example.demo.model.Message;

import java.util.List;

public interface MessageService {
    int saveMessage(Message message);
//    List<Message> getMessagesBetweenUsers(String user1, String user2);
    List<Message> getMessagesByUserId(Long userId);

    void markMessageAsRead(Long messageId);
}
