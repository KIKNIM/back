package com.example.demo.service;

import com.example.demo.model.Drama;
import com.example.demo.repository.DramaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DramaServiceImpl implements DramaService {

    @Autowired
    private DramaRepository dramaRepository;

    @Override
    public List<Drama> getAllDramas() {
        return dramaRepository.findAll();
    }

    @Override
    public List<Drama> getDramasByCategory(String category) {
        return dramaRepository.findByCategory(category);
    }

    @Override
    public List<Drama> searchDramas(String title) {
        return dramaRepository.findByTitleContainingIgnoreCase(title);
    }

    @Override
    public List<Drama> getRecommendedDramas() {
        return dramaRepository.findTop10ByOrderByRatingDesc();
    }

    @Override
    public Optional<Drama> getDramaById(Long dramaId) {
        return dramaRepository.findById(dramaId);
    }
}
