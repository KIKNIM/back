package com.example.demo.service;

import com.example.demo.model.Favorite;
import java.util.List;

public interface FavoriteService {

    List<Favorite> getFavoritesByUser(Long userId);

    Favorite addFavorite(Favorite favorite);

    void deleteFavorite(Long id);

    List<Favorite> getFavoritesByDrama(Long dramaId);
}
