package com.example.demo.repository;

import com.example.demo.model.DownloadRecord;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DownloadRepository extends JpaRepository<DownloadRecord, Long> {
    // 可以根据需求添加查询方法，例如按用户或剧集查询下载记录
}
