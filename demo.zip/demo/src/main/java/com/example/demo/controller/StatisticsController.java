package com.example.demo.controller;

import com.example.demo.model.Statistics;
import com.example.demo.service.StatisticsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/statistics")
public class StatisticsController {

    @Autowired
    private StatisticsService statisticsService;

    // 创建或更新统计记录
    @PostMapping
    public Statistics createOrUpdateStatistics(@RequestBody Statistics statistics) {
        return statisticsService.createOrUpdateStatistics(statistics);
    }

    // 获取指定用户的所有统计记录
    @GetMapping("/user/{userId}")
    public List<Statistics> getStatisticsByUser(@PathVariable Long userId) {
        return statisticsService.getStatisticsByUser(userId);
    }

    // 获取指定短剧的所有统计记录
    @GetMapping("/drama/{dramaId}")
    public List<Statistics> getStatisticsByDrama(@PathVariable Long dramaId) {
        return statisticsService.getStatisticsByDrama(dramaId);
    }

    // 获取指定用户和短剧的统计记录
    @GetMapping("/user/{userId}/drama/{dramaId}")
    public Statistics getStatisticsByUserAndDrama(@PathVariable Long userId, @PathVariable Long dramaId) {
        return statisticsService.getStatisticsByUserAndDrama(userId, dramaId);
    }
}
